#!/usr/bin/env python3
"""
verify_claims.py -- recompute the paper's numerical claims directly from the
committed data files (no orbit integration needed). Addresses reproducibility
of the family/census statistics that the check1-4 scripts do not re-derive.

Usage:  python3 -u verify_claims.py
Prints an explicit PASS/FAIL per claim and a final fingerprint.
"""
import csv, json, math, os, sys

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, "..", "data")

def load_family():
    p = os.path.join(DATA, "cz_familia_winding_completa.csv")
    return list(csv.DictReader(open(p)))

def load_census():
    p = os.path.join(DATA, "cz_route5_POLISHED.json")
    return json.load(open(p))

def check(name, cond, detail=""):
    tag = "PASS" if cond else "FAIL"
    print(f"[{tag}] {name}" + (f"  ({detail})" if detail else ""))
    return cond

def main():
    ok = True
    fam = load_family()
    C   = [float(r["C"])          for r in fam]
    CZ  = [int(float(r["CZ"]))    for r in fam]
    rho = [float(r["rho_deg"])    for r in fam]
    flo = [float(r["floquet_deg"])for r in fam]
    clo = [float(r["closure"])    for r in fam]

    # Claim 1: 56 points
    ok &= check("family has 56 points", len(fam) == 56, f"n={len(fam)}")
    # Claim 2: C-range
    ok &= check("C-range [3.9740, 4.0159]",
                abs(min(C)-3.9740) < 1e-3 and abs(max(C)-4.0159) < 1e-3,
                f"[{min(C):.4f}, {max(C):.4f}]")
    # Claim 3: CZ == 83 everywhere
    ok &= check("CZ = 83 at all 56 points", all(z == 83 for z in CZ),
                f"distinct={sorted(set(CZ))}")
    # Claim 4: rho-range and floor 41
    floors = set(math.floor(abs(x)/360.0) for x in rho)
    ok &= check("floor(|rho|/360) = 41 uniformly", floors == {41},
                f"floors={floors}, rho in [{min(rho):.1f},{max(rho):.1f}]")
    # Claim 5: Floquet interior maximum 36.32 near C=3.9924
    imax = max(range(len(flo)), key=lambda i: flo[i])
    ok &= check("Floquet interior max ~36.32 deg near C~3.9924",
                abs(flo[imax]-36.32) < 0.02 and abs(C[imax]-3.9924) < 2e-3,
                f"max={flo[imax]:.2f} at C={C[imax]:.4f}")
    # Claim 6: closure median ~5e-12, worst ~4e-8, exactly 3 points >1e-9
    sclo = sorted(clo); med = sclo[len(sclo)//2]
    n_bad = sum(1 for x in clo if x > 1e-9)
    ok &= check("closure: median~5e-12, worst~4e-8, 3 pts >1e-9",
                med < 1e-11 and max(clo) < 1e-7 and n_bad == 3,
                f"median={med:.1e}, max={max(clo):.1e}, >1e-9: {n_bad}")
    # Claim 7: no period-doubling proxy -- CZ constant across sign changes of
    # side label (asc/desc) confirms index unchanged through both transitions
    sides = set(r["side"] for r in fam)
    ok &= check("both continuation sides present (asc & desc)",
                {"asc","desc"} <= sides, f"sides={sides}")

    # Census claims
    cen = load_census()
    byname = {c["name"]: c for c in cen}
    a, b = byname.get("alpha"), byname.get("beta")
    ok &= check("census: alpha CZ=3, closure<1e-9",
                a and a["CZ_fisico"] == 3 and abs(a["closure"]) < 1e-9,
                f"CZ={a['CZ_fisico']}, closure={a['closure']:.1e}" if a else "missing")
    ok &= check("census: beta CZ=5, closure<1e-9",
                b and b["CZ_fisico"] == 5 and abs(b["closure"]) < 1e-9,
                f"CZ={b['CZ_fisico']}, closure={b['closure']:.1e}" if b else "missing")
    ok &= check("census: both rho match paper (-655.663 / -836.129)",
                a and b and abs(a["rho_deg"]+655.663) < 1e-2
                       and abs(b["rho_deg"]+836.129) < 1e-2,
                f"alpha rho={a['rho_deg']:.3f}, beta rho={b['rho_deg']:.3f}" if a and b else "missing")

    print()
    if ok:
        print("PASS_VERIFY_CLAIMS")
        return 0
    else:
        print("FAIL_VERIFY_CLAIMS")
        return 1

if __name__ == "__main__":
    sys.exit(main())
