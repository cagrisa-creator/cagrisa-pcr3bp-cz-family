import numpy as np, dill
from scipy.integrate import solve_ivp
E=dill.load(open('engine_mu.dill','rb'));f_rhs=E['f_rhs']
J4=np.array([[0,0,1,0],[0,0,0,1],[-1,0,0,0],[0,-1,0,0]],dtype=float)
def omega(u,v): return u@J4@v
# quaternionic complex structures (state order z1,z2,pz1,pz2; w=zeta1+zeta2 j, zeta_k=z_k+i pz_k)
def Iq(w): return np.array([-w[2],-w[3], w[0], w[1]])
def Jq(w): return np.array([-w[1], w[0], w[3],-w[2]])
def Kq(w): return np.array([-w[3], w[2],-w[1], w[0]])
def sympl_perp(x,a,b,sig): return x - (omega(x,b)/sig)*a + (omega(x,a)/sig)*b

def compute_cz(z0,tauT,mu,c,N=12001,verbose=True):
    def rv(t,Y):
        w_=Y[:4];Phi=Y[4:].reshape(4,4)
        dz=np.array(f_rhs(*w_,mu,c),dtype=float)
        return np.concatenate([dz,(_jac(w_,mu,c)@Phi).ravel()])
    sol=solve_ivp(_rv_factory(mu,c),[0,tauT],np.concatenate([z0,np.eye(4).ravel()]),
                  method='DOP853',rtol=1e-11,atol=1e-13,dense_output=True)
    def frame_at(w_):
        Y=w_/2; XK=np.array(f_rhs(*w_,mu,c),dtype=float); sig=omega(Y,XK)
        u1=sympl_perp(Jq(w_),Y,XK,sig); u2=sympl_perp(Kq(w_),Y,XK,sig)
        k=omega(u1,u2)
        return u1/np.sqrt(k),u2/np.sqrt(k),Y,XK,sig,k
    taus=np.linspace(0,tauT,N)
    u1_0,u2_0,Y0,XK0,sig0,k0=frame_at(sol.sol(0.0)[:4]);U0=np.column_stack([u1_0,u2_0])
    thetas=np.zeros(N);prev=None;acc=0.0;detR=np.zeros(N);Rlast=None;kmin=1e9;sigmin=1e9
    for n,tt in enumerate(taus):
        wv=sol.sol(tt);w_=wv[:4];Phi=wv[4:].reshape(4,4)
        u1,u2,Y,XK,sig,k=frame_at(w_);Ut=np.column_stack([u1,u2])
        kmin=min(kmin,k);sigmin=min(sigmin,sig)
        V=Phi@U0
        V0=sympl_perp(V[:,0],Y,XK,sig);V1=sympl_perp(V[:,1],Y,XK,sig)
        Vp=np.column_stack([V0,V1])
        R,*_=np.linalg.lstsq(Ut,Vp,rcond=None)
        detR[n]=np.linalg.det(R)
        U_,S_,Vt_=np.linalg.svd(R);O=U_@Vt_
        th=np.arctan2(O[1,0],O[0,0])
        if prev is None: acc=th
        else:
            d=th-prev
            while d>np.pi:d-=2*np.pi
            while d<-np.pi:d+=2*np.pi
            acc+=d
        prev=th;thetas[n]=acc;Rlast=R
    rho=thetas[-1]
    CZ_floor=2*int(np.floor(rho/(2*np.pi)))+1
    if verbose:
        print(f"  det(R) range [{detR.min():.6f},{detR.max():.6f}] (deve ser 1)")
        print(f"  min omega(Y,XK)={sigmin:.4f}  min omega(u1,u2)={kmin:.4f} (devem ser >0)")
        print(f"  rho={np.degrees(rho):.4f} deg = {rho/(2*np.pi):.5f} voltas  CZ_floor={CZ_floor}")
    return {'rho_deg':np.degrees(rho),'CZ_floor':CZ_floor,'detR':(detR.min(),detR.max())}

# need jacobian for STM
import sympy as sp
def _build_jac():
    z1,z2,pz1,pz2,mu_,c_=sp.symbols('z1 z2 pz1 pz2 mu c',real=True)
    s=z1**2+z2**2;q1=2*(z1**2-z2**2);q2=-4*z1*z2
    pq1=(z1*pz1-z2*pz2)/(4*s);pq2=-(z2*pz1+z1*pz2)/(4*s)
    r1=2*s;r2=sp.sqrt((q1-1)**2+q2**2)
    H=sp.Rational(1,2)*(pq1**2+pq2**2)+q2*pq1-(q1-mu_)*pq2-(1-mu_)/r1-mu_/r2
    K=4*s*(H-c_)
    Yv=sp.Matrix([z1,z2,pz1,pz2])
    F=sp.Matrix([sp.diff(K,pz1),sp.diff(K,pz2),-sp.diff(K,z1),-sp.diff(K,z2)])
    return sp.lambdify((z1,z2,pz1,pz2,mu_,c_),F.jacobian(Yv),'numpy')
_JAC=_build_jac()
def _jac(w_,mu,c): return np.array(_JAC(*w_,mu,c),dtype=float)
def _rv_factory(mu,c):
    def rv(t,Y):
        w_=Y[:4];Phi=Y[4:].reshape(4,4)
        return np.concatenate([np.array(f_rhs(*w_,mu,c),dtype=float),(_jac(w_,mu,c)@Phi).ravel()])
    return rv

if __name__=='__main__':
    w=np.load('robust_witness.npz');z0=w['z0'];tauT=float(w['tauT']);c=float(w['c']);mu=0.5
    print("ROTA Q — witness (mu=0.5), deve dar CZ_floor coerente com |CZ|=83:")
    for N in (6001,12001):
        o=compute_cz(z0,tauT,mu,c,N=N)
