#!/usr/bin/env python3
"""Check 1: witness orbit, Rota Q CZ.
Fingerprints: closure<5e-9, rho=-14805.68 deg, CZ_floor=-83 (physical +83), det(R)=1."""
import numpy as np, dill, rota_q as RQ
from robust_newton_lib import correct, prop_end
E=dill.load(open('engine_mu.dill','rb'));H_fun=E['H_fun']
mu=0.5
z0g=np.array([0.4659788519,0.0460081239,0.28246705,0.39408406])  # LC witness (checkpoint)
c=float(H_fun(*z0g,mu))
z0,tauT,clo=correct(z0g,88.9932,mu,c)
assert clo<5e-9, f"closure {clo}"
print(f"witness reconverged: closure={clo:.2e} tau_T={tauT:.6f} c={c:.9f}")
ok=True
for N in (6001,12001):
    o=RQ.compute_cz(z0,tauT,mu,c,N=N,verbose=False)
    print(f"  N={N}: rho={o['rho_deg']:.4f} CZ_floor={o['CZ_floor']}")
    ok &= (o['CZ_floor']==-83) and abs(o['rho_deg']-(-14805.684))<0.01
print("PASS_CHECK1_WITNESS_CZ83" if ok else "FAIL_CHECK1")
np.savez('witness.npz',z0=z0,tauT=tauT,c=c,mu=mu)
