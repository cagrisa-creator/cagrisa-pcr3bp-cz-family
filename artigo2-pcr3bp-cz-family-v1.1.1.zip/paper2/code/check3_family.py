#!/usr/bin/env python3
"""Check 3: CZ=83 along the continuation family (sample points spanning both
bifurcations). Uses phase+energy-pinned Newton to reconverge at target C,
then Rota Q. Fingerprint: CZ_floor=-83 at all sampled C."""
import numpy as np, dill, rota_q as RQ
from robust_newton_lib import correct, prop_end
E=dill.load(open('engine_mu.dill','rb'));H_fun=E['H_fun']
mu=0.5
w=np.load('witness.npz');z0=w['z0'];tauT=float(w['tauT'])
targets=[4.000,3.996,3.990,3.986,3.982,4.006,4.012]  # spans both bifurcations
# march by continuation from witness toward each side
def march(z0,tauT,C0,targets_side,sign):
    out=[];z,t,Cc=z0.copy(),tauT,C0
    tlist=sorted([T for T in targets_side],reverse=(sign<0))
    for Ct in tlist:
        while (Cc-Ct)*sign > 1e-9:
            Cn=Cc-sign*min(0.001,abs(Cc-Ct));c=-Cn/2
            z,t,clo=correct(z,t,mu,c)
            assert clo<1e-7, f"break at C={Cn}: {clo}"
            Cc=Cn
        o=RQ.compute_cz(z,t,mu,-Cc/2,N=6001,verbose=False)
        out.append((Cc,o['CZ_floor']))
        print(f"  C={Cc:.4f}: CZ_floor={o['CZ_floor']}")
    return out
print("descending side:")
r1=march(z0,tauT,4.002,[T for T in targets if T<4.002],+1)
print("ascending side:")
r2=march(z0,tauT,4.002,[T for T in targets if T>4.002],-1)
ok=all(cz==-83 for _,cz in r1+r2)
print("PASS_CHECK3_FAMILY_CZ83" if ok else "FAIL_CHECK3")
