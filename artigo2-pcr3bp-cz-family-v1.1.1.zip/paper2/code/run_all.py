#!/usr/bin/env python3
"""Run the reproducibility suite.

Modes:
  python3 -u run_all.py            full suite (~15-25 min; check3 is the long step)
  python3 -u run_all.py --smoke    fast path: engine + witness + census + verify_claims
                                    (skips the ~40-60 min family march, check3)
  python3 -u run_all.py --verify   data-only: recompute all reported statistics
                                    from the committed CSV/JSON (seconds, no integration)

Order matters: engine first, then witness (creates witness.npz), then the rest.
Logs go to RUN_ALL_<UTC>.log in addition to stdout.
"""
import subprocess, sys, time, datetime, platform, os
os.chdir(os.path.dirname(os.path.abspath(__file__)))

FULL   = ["engine_build.py","check1_witness.py","check2_kepler_anchor.py",
          "check3_family.py","check4_symmetric_census.py","verify_claims.py"]
SMOKE  = ["engine_build.py","check1_witness.py","check2_kepler_anchor.py",
          "check4_symmetric_census.py","verify_claims.py"]
VERIFY = ["verify_claims.py"]

def run(steps, logname):
    log = open(logname, "w")
    hdr = (f"# run_all {datetime.datetime.utcnow().isoformat()}Z\n"
           f"# {platform.platform()} | python {platform.python_version()}\n")
    print(hdr); log.write(hdr)
    for s in steps:
        banner = f"\n{'='*60}\nRUNNING {s}\n{'='*60}"
        print(banner, flush=True); log.write(banner+"\n"); log.flush()
        t0 = time.time()
        r = subprocess.run([sys.executable, "-u", s],
                           capture_output=True, text=True)
        sys.stdout.write(r.stdout); sys.stdout.flush()
        log.write(r.stdout)
        if r.stderr:
            sys.stderr.write(r.stderr); log.write(r.stderr)
        dt = time.time()-t0
        tail = f"[{s}: {dt:.1f}s, rc={r.returncode}]"
        print(tail, flush=True); log.write(tail+"\n"); log.flush()
        if r.returncode != 0:
            print(f"STOP: {s} failed"); log.write(f"STOP: {s} failed\n")
            log.close(); sys.exit(1)
    print("\nALL CHECKS PASSED"); log.write("\nALL CHECKS PASSED\n"); log.close()

if __name__ == "__main__":
    mode = sys.argv[1] if len(sys.argv) > 1 else "--full"
    steps = {"--full":FULL, "--smoke":SMOKE, "--verify":VERIFY}.get(mode)
    if steps is None:
        print(f"unknown mode {mode!r}; use --full | --smoke | --verify"); sys.exit(2)
    stamp = datetime.datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
    run(steps, f"RUN_ALL_{stamp}.log")
