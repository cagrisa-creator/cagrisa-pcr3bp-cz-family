#!/usr/bin/env python3
"""Build the Levi-Civita regularized engine (symbolic, audited).
K = 4s(H-c), s=z1^2+z2^2, LC map q=2*conj(z)^2, cotangent lift.
Audit A1: symbolic residual of Hamilton's equations vs documented EOM must be 0.
Outputs: engine_mu.dill (f_rhs,f_jac,H_fun,K_fun), gradH.dill"""
import sympy as sp, dill

z1,z2,pz1,pz2,mu,c = sp.symbols('z1 z2 pz1 pz2 mu c', real=True)
s  = z1**2 + z2**2
q1 = 2*(z1**2 - z2**2); q2 = -4*z1*z2
pq1 = (z1*pz1 - z2*pz2)/(4*s); pq2 = -(z2*pz1 + z1*pz2)/(4*s)
r1 = 2*s; r2 = sp.sqrt((q1-1)**2 + q2**2)
H = sp.Rational(1,2)*(pq1**2+pq2**2) + q2*pq1 - (q1-mu)*pq2 - (1-mu)/r1 - mu/r2
K = 4*s*(H - c)
dz1 = sp.diff(K,pz1); dz2 = sp.diff(K,pz2)
dpz1 = -sp.diff(K,z1); dpz2 = -sp.diff(K,z2)
# AUDIT A1
dz1_doc = -mu*z2 + pz1/4 - 2*z1**2*z2 - 2*z2**3
dz2_doc = -mu*z1 + pz2/4 + 2*z1**3 + 2*z1*z2**2
r1_ = sp.simplify(dz1-dz1_doc); r2_ = sp.simplify(dz2-dz2_doc)
assert r1_==0 and r2_==0, f"A1 FAIL: {r1_}, {r2_}"
print("A1 PASS: symbolic residual 0 (both equations)")
Y = sp.Matrix([z1,z2,pz1,pz2]); F = sp.Matrix([dz1,dz2,dpz1,dpz2])
eng = dict(
  f_rhs=sp.lambdify((z1,z2,pz1,pz2,mu,c),[dz1,dz2,dpz1,dpz2],'numpy'),
  f_jac=sp.lambdify((z1,z2,pz1,pz2,mu,c),F.jacobian(Y),'numpy'),
  H_fun=sp.lambdify((z1,z2,pz1,pz2,mu),H,'numpy'),
  K_fun=sp.lambdify((z1,z2,pz1,pz2,mu,c),K,'numpy'))
dill.dump(eng,open('engine_mu.dill','wb'))
dill.dump(dict(gradH=sp.lambdify((z1,z2,pz1,pz2,mu),[sp.diff(H,v) for v in (z1,z2,pz1,pz2)],'numpy')),open('gradH.dill','wb'))
print("PASS_ENGINE_BUILD")
