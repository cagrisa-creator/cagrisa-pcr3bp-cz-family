#!/usr/bin/env python3
"""Check 4: symmetric census at witness energy. The 4 simple symmetric orbits are
2 distinct orbits (mirror pairs under the P1<->P2 symmetry of mu=0.5).
Cover fixed by winding number around the regularized primary (odd -> cover 2).
Fingerprints: alpha CZ_floor=-3, beta CZ_floor=-5 (physical 3 and 5, both >=3, odd)."""
import numpy as np, dill, rota_q as RQ
from scipy.integrate import solve_ivp
from robust_newton_lib import correct
E=dill.load(open('engine_mu.dill','rb'));f_rhs=E['f_rhs'];H_fun=E['H_fun']
mu=0.5
orbs=[("alpha",-0.652243,1.964618,0.4859,-3),("beta",-0.250966,1.186639,1.3228,-5)]
ok=True
for name,x0,vy0,T,cz_expect in orbs:
    y0=np.array([x0+mu,0.0,0.0,vy0+x0])
    Q=y0[0]+1j*y0[1];zc=np.conj(np.sqrt(Q/2));z1_0,z2_0=zc.real,zc.imag
    Jm=np.array([[4*z1_0,-4*z2_0],[-4*z2_0,-4*z1_0]]);pz=Jm@np.array([y0[2],y0[3]])
    z0=np.array([z1_0,z2_0,pz[0],pz[1]]);c=float(H_fun(*z0,mu))
    def rv_t(t,Y):
        y=Y[:4];s=y[0]**2+y[1]**2
        return np.concatenate([np.array(f_rhs(*y,mu,c),dtype=float),[4*s]])
    ev=lambda t,Y:Y[4]-2*T;ev.terminal=True;ev.direction=1
    st=solve_ivp(rv_t,[0,40*T],np.concatenate([z0,[0.]]),method='DOP853',rtol=1e-11,atol=1e-11,events=ev)
    z1,tau1,clo=correct(z0,st.t_events[0][0],mu,c)
    o=RQ.compute_cz(z1,tau1,mu,c,N=12001,verbose=False)
    print(f"  {name}: closure={clo:.2e} CZ_floor={o['CZ_floor']} (expect {cz_expect})")
    ok &= (o['CZ_floor']==cz_expect) and clo<1e-10
print("PASS_CHECK4_SYMMETRIC_CENSUS" if ok else "FAIL_CHECK4")
