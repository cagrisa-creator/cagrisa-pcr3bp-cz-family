#!/usr/bin/env python3
"""Phase+energy-pinned Newton (Golden Rule 14).
Residual: [closure(4), phase(1), energy(1)]; unknowns (z0[4], tauT); analytic 6x5 Jacobian.
Fixed point property: re-applying moves (z0,tauT) by exactly 0."""
import numpy as np, dill
from scipy.integrate import solve_ivp
from scipy.optimize import least_squares
import rota_q as RQ
E=dill.load(open('engine_mu.dill','rb'));f_rhs=E['f_rhs'];H_fun=E['H_fun']
gradH=dill.load(open('gradH.dill','rb'))['gradH']

def prop_end(z0,tauT,mu,c,rtol=1e-12):
    def rv(t,Y):
        y=Y[:4];Phi=Y[4:].reshape(4,4)
        return np.concatenate([np.array(f_rhs(*y,mu,c),dtype=float),(RQ._jac(y,mu,c)@Phi).ravel()])
    s=solve_ivp(rv,[0,tauT],np.concatenate([z0,np.eye(4).ravel()]),method='DOP853',rtol=rtol,atol=rtol)
    return s.y[:4,-1],s.y[4:,-1].reshape(4,4)

def correct(zg,tg,mu,c,max_nfev=80):
    fp=np.array(f_rhs(*zg,mu,c),dtype=float);zp=zg.copy();cache={}
    def get(x):
        k=x.tobytes()
        if k not in cache:cache[k]=prop_end(x[:4],x[4],mu,c)
        return cache[k]
    def resid(x):
        zT,M=get(x);return np.concatenate([zT-x[:4],[np.dot(x[:4]-zp,fp)],[float(H_fun(*x[:4],mu))-c]])
    def jac(x):
        zT,M=get(x);fT=np.array(f_rhs(*zT,mu,c),dtype=float)
        J=np.zeros((6,5));J[:4,:4]=M-np.eye(4);J[:4,4]=fT;J[4,:4]=fp;J[5,:4]=np.array(gradH(*x[:4],mu));return J
    r=least_squares(resid,np.concatenate([zg,[tg]]),jac=jac,method='lm',xtol=1e-14,ftol=1e-14,gtol=1e-14,max_nfev=max_nfev)
    return r.x[:4],r.x[4],np.linalg.norm(resid(r.x)[:4])
