#!/usr/bin/env python3
"""Check 2: rotating-Kepler retrograde anchor (low-CZ calibration).
Correct rotating-frame IC: omega=-1-n from (omega+1)^2=1/r0^3, p2_0=-r0*n.
LC double cover: tau_LC = 2*tau(T_phys), verified by z(tau_phys) = -z0.
Fingerprint: CZ_floor=-3 (physical +3, literature value)."""
import numpy as np, dill, rota_q as RQ
from scipy.integrate import solve_ivp
E=dill.load(open('engine_mu.dill','rb'));f_rhs=E['f_rhs'];H_fun=E['H_fun']
mu=1e-6; r0=0.5; n=np.sqrt((1-mu)/r0**3); omega=-1-n
q1_0,q2_0=r0,0.0; qd1,qd2=0.0,r0*omega
p1_0,p2_0=qd1-q2_0,qd2+q1_0
Q=q1_0+1j*q2_0;zc=np.conj(np.sqrt(Q/2));z1_0,z2_0=zc.real,zc.imag
Jm=np.array([[4*z1_0,-4*z2_0],[-4*z2_0,-4*z1_0]]);pz=Jm@np.array([p1_0,p2_0])
z0=np.array([z1_0,z2_0,pz[0],pz[1]]);c=float(H_fun(*z0,mu))
T_phys=2*np.pi/abs(omega)
def rv_t(t,Y):
    y=Y[:4];s=y[0]**2+y[1]**2
    return np.concatenate([np.array(f_rhs(*y,mu,c),dtype=float),[4*s]])
ev=lambda t,Y:Y[4]-T_phys;ev.terminal=True;ev.direction=1
st=solve_ivp(rv_t,[0,10*T_phys],np.concatenate([z0,[0.]]),method='DOP853',rtol=1e-12,atol=1e-12,events=ev,dense_output=True)
tau_phys=st.t_events[0][0]
dc=np.linalg.norm(st.sol(tau_phys)[:4]+z0)   # double-cover check: z(tau_phys) = -z0
assert dc<1e-4, f"double cover check failed: {dc}"
print(f"double cover verified: |z(tau_phys)+z0|={dc:.2e}")
tau_LC=2*tau_phys
ok=True
for N in (6001,12001):
    o=RQ.compute_cz(z0,tau_LC,mu,c,N=N,verbose=False)
    print(f"  N={N}: rho={o['rho_deg']:.4f} CZ_floor={o['CZ_floor']}")
    ok &= (o['CZ_floor']==-3)
print("PASS_CHECK2_KEPLER_CZ3" if ok else "FAIL_CHECK2")
