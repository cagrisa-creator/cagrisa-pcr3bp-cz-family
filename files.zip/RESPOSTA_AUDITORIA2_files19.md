# RESPOSTA À SEGUNDA AUDITORIA (files19) — resolução ponto a ponto
**Data:** 08/07/2026 · Pacote resultante: artigo2-pcr3bp-cz-family-**v1.1.1**

A segunda auditoria (independente) pegou achados reais que a primeira não
pegou — em especial um erro matemático no corpo (F4). Todos verificados
contra fonte/dados antes de corrigir. Veredito: os bloqueios foram
resolvidos; resta apenas o passo humano do DOI (C2), inerente ao fluxo.

═══════════════════════════════════════════════════════════════════════════
## F4 — Afirmação topológica π₃(Sp(2,ℝ))=0  → CORRIGIDO (era erro real)
═══════════════════════════════════════════════════════════════════════════
VERIFICADO contra fontes (Sansour/CZ-index notes; Long, index theory):
o grupo simplético Sp(ℝ^{2n}) retrai sobre seu compacto maximal U(n) —
logo Sp(2,ℝ) (4×4, n=2) retrai sobre U(2), NÃO sobre S¹. A frase misturava
o grupo 4×4 com a topologia do 2×2. Além disso, o objeto que controla
trivialização de frame num plano 2D é π₁, não π₃.
CORREÇÃO (abstract e §4.1): as fibras de contato são 2-dimensionais, então
mudanças de frame tomam valores em Sp(1,ℝ) ≃ SL(2,ℝ), que retrai sobre
SO(2) ≃ S¹; a classe de homotopia é governada por π₁ e o frame
quaterniônico a fixa canonicamente. (Ambas as ocorrências corrigidas.)

═══════════════════════════════════════════════════════════════════════════
## F5 — Bibliografia (Kim)  → CORRIGIDO (era erro real)
═══════════════════════════════════════════════════════════════════════════
VERIFICADO em arXiv: 1701.07258 = Seongchan Kim, "On a convex embedding of
the Euler problem of two fixed centers" (Regul. Chaotic Dyn. 23 (2018)
304–324) — NÃO "On the convexity of the Levi-Civita embedding", e autor
S.~Kim (não J.). Corrigido. Também:
- Adicionada Kim, "Dynamical convexity of the Euler problem of two fixed
  centers" (arXiv:1601.02045) — diretamente relevante à Fase 1 do plano.
- Atribuição no corpo tornada precisa: Kim é sobre coordenadas elípticas
  do problema de Euler (obstrução análoga por assimetria de massa); o
  resultado LC é do Artigo 1 (Grisa1). Antes estavam indevidamente juntos.

═══════════════════════════════════════════════════════════════════════════
## F2 — sha256sum quebra após rodar engine_build  → CORRIGIDO (era real)
═══════════════════════════════════════════════════════════════════════════
Os .dill (engine_mu, gradH) são GERADOS por engine_build.py e não são
byte-determinísticos; witness.npz é gerado por check1. SHA256SUMS.txt agora
cobre APENAS fonte+dados+paper (16 arquivos), excluindo os 3 artefatos
gerados. Rodar a suíte não invalida mais o `sha256sum -c`. Política
documentada no README ("Integrity note"). Verificado: 16/16 OK antes e
depois de rodar --smoke.

═══════════════════════════════════════════════════════════════════════════
## F3 — run_all.py não-auditável  → CORRIGIDO (melhoria adotada)
═══════════════════════════════════════════════════════════════════════════
run_all.py reescrito:
- `python3 -u` (flush) + captura e eco de stdout/stderr em tempo real;
- grava RUN_ALL_<UTC>.log com plataforma, versão do Python e tempo/etapa;
- três modos: `--full` (default), `--smoke` (pula check3 de 40-60 min),
  `--verify` (só recomputa estatísticas dos dados, segundos);
- resolve o próprio diretório (roda de qualquer lugar).
TESTE DE REPRODUÇÃO (o que a auditoria não conseguiu concluir):
`--smoke` roda ponta-a-ponta em ~64 s neste ambiente:
  engine_build      PASS (residual simbólico 0)
  check1_witness    PASS  rho=-14805.6840  CZ=+83  (N-estável 6001/12001)
  check2_kepler     PASS  CZ=+3
  check4_census     PASS  CZ=3,5  (closures 6e-16 / 1e-14)
  verify_claims     PASS_VERIFY_CLAIMS

═══════════════════════════════════════════════════════════════════════════
## F6 — Afirmações fortes sem script  → CORRIGIDO (verificador adicionado)
═══════════════════════════════════════════════════════════════════════════
Novo `code/verify_claims.py` recomputa DOS DADOS COMMITADOS, sem integração:
56 pontos; C∈[3.9740,4.0159]; CZ≡83; floor(|ρ|/360)=41 uniforme; Floquet
máx 36.32° em C=3.9924; closure mediana 5.2e-12 / máx 4.2e-8 / exatamente
3 pontos >1e-9; ambos os lados da continuação presentes; censo α CZ=3 /
β CZ=5 com ρ batendo −655.663 / −836.129. Todos os 10 → PASS_VERIFY_CLAIMS.
NOTA: as afirmações que dependem de estados/integração (min|λ−(−1)|≥1.43,
ausência de fold, cross-check cartesiano) são reproduzidas por check3
(marcha completa); verify_claims cobre o que é derivável dos ledgers. A
combinação check3 + verify_claims fecha o flanco de F6.

═══════════════════════════════════════════════════════════════════════════
## F1 — dill faltando no ambiente da auditoria  → NÃO é bug do pacote
═══════════════════════════════════════════════════════════════════════════
O README já lista `dill` como dependência. Falha de ambiente do auditor,
não do pacote. Sem ação (opcional: poderíamos remover a dependência de
dill serializando o engine de outra forma — não vale o esforço agora).

═══════════════════════════════════════════════════════════════════════════
## PENDÊNCIA QUE PERMANECE (inerente ao fluxo, não é defeito)
═══════════════════════════════════════════════════════════════════════════
C2 (DOI): o placeholder DOI:XXXXXXX está no tex DE PROPÓSITO — o DOI só
existe DEPOIS que você publica no Zenodo (Passo 3 das instruções). O
Passo 4 insere o DOI e refaz os checksums. Não é possível pré-preencher.

═══════════════════════════════════════════════════════════════════════════
## CONVERGÊNCIA DAS DUAS AUDITORIAS
═══════════════════════════════════════════════════════════════════════════
1ª auditoria (numérica): ρ-range, Floquet-C, closure honesto → corrigidos v1.1.0
2ª auditoria (estrutural): F4 topologia, F5 Kim, F2 checksums, F3 logs,
  F6 verificador → corrigidos v1.1.1
Sobreposição zero, complementaridade total. O manuscrito agora está
factual e estruturalmente consistente.

## VEREDITO ATUALIZADO
Pronto para o fluxo GitHub→Zenodo→HAL→journal, condicionado APENAS à
inserção do DOI (C2, passo humano no meio do fluxo). Recomendações
opcionais remanescentes (não-bloqueantes): re-convergir os 3 pontos de
closure ~1e-8 (C1); confirmar ano/página de AFFHvK na fonte primária.
