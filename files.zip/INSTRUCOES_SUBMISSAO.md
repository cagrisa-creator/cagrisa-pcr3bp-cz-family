# INSTRUÇÕES DE SUBMISSÃO — Artigo 2 (v1.1.0)
**Estas etapas são executadas por você (César).** Envolvem login, publicação
pública e aceite de termos — não posso fazê-las em seu nome. O pacote abaixo
está pronto; siga na ordem.

Arquivo do pacote: `artigo2-pcr3bp-cz-family-v1.1.0.zip`

═══════════════════════════════════════════════════════════════════════════
## PASSO 1 — GitHub
═══════════════════════════════════════════════════════════════════════════
1.1 Crie (ou use) o repositório `github.com/cagrisa/pcr3bp-cz-family`.
    (O README e o main.tex já apontam para esta URL — se usar outro nome,
    ajuste a linha \url{...github.com...} no main.tex antes.)
1.2 Descompacte o zip e faça commit de TODO o conteúdo na raiz do repo
    (README.md, LICENSE, CITATION.cff, .zenodo.json, paper2/).
1.3 Confirme a integridade antes do commit:
      cd paper2 && sha256sum -c SHA256SUMS.txt
    Deve dar "OK" em 18 arquivos (o próprio SHA256SUMS.txt não se auto-checa).
1.4 NÃO crie a release/tag ainda — o Zenodo captura no momento da tag.

═══════════════════════════════════════════════════════════════════════════
## PASSO 2 — Conectar Zenodo ao GitHub
═══════════════════════════════════════════════════════════════════════════
2.1 Em zenodo.org, faça login, vá em Settings → GitHub, e ATIVE o toggle
    do repositório pcr3bp-cz-family.
    (O arquivo .zenodo.json na raiz já traz título, autor, keywords,
    licença MIT e versão 1.1.0 — o Zenodo lê automaticamente.)

═══════════════════════════════════════════════════════════════════════════
## PASSO 3 — Criar a release (dispara o DOI)
═══════════════════════════════════════════════════════════════════════════
3.1 No GitHub: Releases → Draft a new release → Tag `v1.1.0`.
3.2 Título: "v1.1.0 — CZ near-collision family (PCR3BP, mu=0.5)".
3.3 Publish release. O Zenodo captura e emite um DOI em ~1-2 min.
3.4 Anote o DOI (formato 10.5281/zenodo.XXXXXXX).

═══════════════════════════════════════════════════════════════════════════
## PASSO 4 — Inserir o DOI no manuscrito e re-lacrar  [OBRIGATÓRIO]
═══════════════════════════════════════════════════════════════════════════
4.1 Em paper2/paper/main.tex, ache a linha com o marcador (seção
    Reproducibility, "Data availability"):
        \href{https://doi.org/XXXXXXX}{\texttt{DOI:XXXXXXX}} % <-- REPLACE ...
    Troque os DOIS "XXXXXXX" pelo DOI real. Remova o comentário "<-- REPLACE".
4.2 Recompile: `pdflatex main.tex` (2x). Confirme 7 páginas, sem erros.
4.3 Regenere os checksums:
        cd paper2 && rm SHA256SUMS.txt
        find . -type f -not -name SHA256SUMS.txt | sort | xargs sha256sum > SHA256SUMS.txt
4.4 Commit da atualização do DOI. (Opcional: release v1.1.1 se quiser que
    o Zenodo arquive a versão já com DOI embutido — recomendado para o
    registro ficar autoconsistente. O DOI "concept" do Zenodo aponta
    sempre para a última versão, então citar o concept-DOI é seguro.)

═══════════════════════════════════════════════════════════════════════════
## PASSO 5 — HAL
═══════════════════════════════════════════════════════════════════════════
5.1 Em hal.science, faça login → Deposit.
5.2 Suba o main.pdf JÁ COM O DOI (do passo 4.2).
5.3 Metadados: título e abstract do main.tex; domínio math.DS / math.SG;
    autor UFF; adicione o DOI do Zenodo como "related identifier"
    (relation: "is supplemented by").
5.4 Submeta. O HAL gera um identificador hal-XXXXXXXX.

═══════════════════════════════════════════════════════════════════════════
## PASSO 6 — Journal (Experimental Mathematics)
═══════════════════════════════════════════════════════════════════════════
6.1 Confirme escopo/formato em tandfonline (Experimental Mathematics é
    Taylor & Francis). Alternativa de fallback: SIAM J. Applied Dynamical
    Systems (SIADS).
6.2 Cover letter: use COVER_LETTER_artigo2.md (rascunho pronto, revise).
6.3 Anexe o main.pdf e o link do repositório/DOI na seção de dados.
6.4 Sugestão de referees: evitar os grupos diretamente competidores
    (van Koert, Salomão) por conflito; sugerir nomes da comunidade de
    computer-assisted proofs em sistemas dinâmicos.

═══════════════════════════════════════════════════════════════════════════
## CHECKLIST RÁPIDO
═══════════════════════════════════════════════════════════════════════════
[ ] 1. GitHub: conteúdo commitado, sha256sum -c OK
[ ] 2. Zenodo: toggle do repo ativado
[ ] 3. Release v1.1.0 criada → DOI emitido
[ ] 4. DOI inserido no main.tex, recompilado, checksums refeitos
[ ] 5. HAL: PDF com DOI depositado
[ ] 6. Journal: cover letter + submissão

## PENDÊNCIAS DA AUDITORIA A DECIDIR ANTES (ver RELATORIO_AUDITORIA_artigo2.md)
[ ] C1 [opcional]: re-convergir 3 pontos de closure ~1e-8 (1 sessão)
[ ] C3 [recomendado]: conferir ano/página de AFFHvK e Kim na fonte
